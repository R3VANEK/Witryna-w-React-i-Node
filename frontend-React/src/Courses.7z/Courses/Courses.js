import React from "react";
import Navbar from "../Navbar/Navbar.js";
import "./Courses.css";
import Course from "../Course/Course.js";
import JSON_data1 from "../Data/courseData.json";

const Courses = props => {
  const renderCards = JSON_data1.course.map(element => {
    console.log(element.completion);
    return (
      <Course
        id={element.id}
        title={element.title}
        front_text={element.front_text}
        author={element.author}
        header={element.header}
        list={element.list}
        percentage={element.completion}
        key={element.id}
      />
    );
  });

  if (props.isRender === "Courses") {
    return (
      <div className="courses-main-container">
        {/* <div id="Courses-holder"> */}
        <Navbar
          user={props.data}
          out={props.logOut}
          accountRender={props.accountRender}
        />
        <div className="card-main-container">
          {renderCards}
          {/* <div className="bg"></div> */}
        </div>
        <footer>&copy; Copyright 2020 - Jan Napieralski, Łukasz Czapski</footer>
      </div>
    );
  } else {
    return null;
  }
};

export default Courses;
