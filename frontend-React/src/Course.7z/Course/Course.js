import React from "react";
import "./Course.css";

const Course = props => {
  const liElements = props.list.map(el => {
    return <li className="extra-element">{el}</li>;
  });

  return (
    <div className="cards-holder" id={props.id}>
      {
        <div className="card-face front-face">
          <div className="Course-img"></div>
          <div className="hover-div">
            <div className="info-wrapper">
              <h1 className="kurs-h2">{props.header}</h1>
              <p className="course-author">By {props.author}</p>
              <p className="course-short">{props.text}</p>
            </div>
            <div className="button-wrapper">
              <button className="mdc-button mdc-button--raised">
                {" "}
                <span className="mdc-button__ripple"></span> Więcej
              </button>
            </div>

            {/* <button className="course-read">Read</button> */}
          </div>
        </div>
      }

      <div className="card-face back-face">
        <div className="info-wrapper">
          <h1 className="kurs-h2">{props.title}</h1>
          <p className="percentage">{props.percentage}</p>
          <p className="course-author">By {props.author}</p>
          <p className="back-main-text">{props.header}</p>
          <p className="what-to-learn">Czego nauczysz się na tym kursie : </p>
          <ul className="extra-list">{liElements}</ul>
        </div>
        <div className="button-wrapper">
          <button className="mdc-button mdc-button--raised">
            {" "}
            <span className="mdc-button__ripple"></span> Rozpocznij naukę
          </button>
        </div>
      </div>
    </div>
  );
};

export default Course;
